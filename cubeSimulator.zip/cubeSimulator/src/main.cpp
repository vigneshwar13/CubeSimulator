#include <SDL2/SDL.h>
#include "Renderer.h"
#include "Cube.h"

int main()
{
    Renderer renderer;
    Cube cube;

    if (!renderer.initialize())
        return -1;

    bool running = true;
    SDL_Event event;

    while (running)
    {
        // ----------------------------
        // Event Handling
        // ----------------------------
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
            {
                running = false;
            }

            // Keyboard Handling
            if (event.type == SDL_KEYDOWN)
            {
                switch (event.key.keysym.sym)
                {
                    case SDLK_UP:
                        cube.rotateUp();
                        break;

                    case SDLK_DOWN:
                        cube.rotateDown();
                        break;

                    case SDLK_LEFT:
                        cube.rotateLeft();
                        break;

                    case SDLK_RIGHT:
                        cube.rotateRight();
                        break;

                    case SDLK_SPACE:
                        cube.reset();
                        break;

                    case SDLK_ESCAPE:
                        running = false;
                        break;
                }
            }
        }

        // ----------------------------
        // Draw
        // ----------------------------
        renderer.clear();
        renderer.drawCube3D(cube);
        renderer.present();
    }

    return 0;
}
