#include "Cube.h"

Cube::Cube(){
    initialize();
}

void Cube::initialize()
{
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cube[TOP][i][j] = WHITE;
            cube[BOTTOM][i][j] = YELLOW;
            cube[FRONT][i][j] = GREEN;
            cube[BACK][i][j] = BLUE;
            cube[LEFT][i][j] = ORANGE;
            cube[RIGHT][i][j] = RED;
        }
    }
}

void Cube::reset(){
    initialize();
}

Color (*Cube::getFace(Face face))[3]{
    return cube[face];
}

void Cube::rotateUp()
{
    Color temp[3][3];

    memcpy(temp, cube[TOP], sizeof(temp));
    memcpy(cube[TOP], cube[FRONT], sizeof(temp));
    memcpy(cube[FRONT], cube[BOTTOM], sizeof(temp));
    memcpy(cube[BOTTOM], cube[BACK], sizeof(temp));
    memcpy(cube[BACK], temp, sizeof(temp));
}

void Cube::rotateDown(){
    Color temp[3][3];

    memcpy(temp, cube[TOP], sizeof(temp));
    memcpy(cube[TOP], cube[BACK], sizeof(temp));
    memcpy(cube[BACK], cube[BOTTOM], sizeof(temp));
    memcpy(cube[BOTTOM], cube[FRONT], sizeof(temp));
    memcpy(cube[FRONT], temp, sizeof(temp));
}

void Cube::rotateLeft(){
    Color temp[3][3];

    memcpy(temp, cube[FRONT], sizeof(temp));
    memcpy(cube[FRONT], cube[LEFT], sizeof(temp));
    memcpy(cube[LEFT], cube[BACK], sizeof(temp));
    memcpy(cube[BACK], cube[RIGHT], sizeof(temp));
    memcpy(cube[RIGHT], temp, sizeof(temp));
}

void Cube::rotateRight(){
    Color temp[3][3];

    memcpy(temp, cube[FRONT], sizeof(temp));
    memcpy(cube[FRONT], cube[RIGHT], sizeof(temp));
    memcpy(cube[RIGHT], cube[BACK], sizeof(temp));
    memcpy(cube[BACK], cube[LEFT], sizeof(temp));
    memcpy(cube[LEFT], temp, sizeof(temp));
}
