#include "FaceGeometry.h"

void FaceGeometry::buildFront(
        int ox,
        int oy,
        int s)
{
    for(int r=0;r<3;r++)
    {
        for(int c=0;c<3;c++)
        {
            Quad &q=stickers[r][c];

            q.p[0]=Point2D(ox+c*s,oy+r*s);
            q.p[1]=Point2D(ox+(c+1)*s,oy+r*s);
            q.p[2]=Point2D(ox+(c+1)*s,oy+(r+1)*s);
            q.p[3]=Point2D(ox+c*s,oy+(r+1)*s);
        }
    }
}

void FaceGeometry::buildTop(int ox, int oy, int s)
{
    int skew = s / 2;

    for (int r = 0; r < 3; r++)
    {
        for (int c = 0; c < 3; c++)
        {
            Quad &q = stickers[r][c];

            int x = ox + c * s + r * skew;
            int y = oy - r * skew;

            q.p[0] = Point2D(x, y);
            q.p[1] = Point2D(x + s, y);
            q.p[2] = Point2D(x + s + skew, y - skew);
            q.p[3] = Point2D(x + skew, y - skew);
        }
    }
}

void FaceGeometry::buildRight(
        int ox,
        int oy,
        int s)
{
    int skew=s/2;

    for(int r=0;r<3;r++)
    {
        for(int c=0;c<3;c++)
        {
            Quad &q=stickers[r][c];

            int x=ox+3*s+c*skew;
            int y=oy+r*s-c*skew;

            q.p[0]=Point2D(x,y);
            q.p[1]=Point2D(x+skew,y-skew);
            q.p[2]=Point2D(x+skew,y+s-skew);
            q.p[3]=Point2D(x,y+s);
        }
    }
}
