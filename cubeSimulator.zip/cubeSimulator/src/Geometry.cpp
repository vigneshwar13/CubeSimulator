#include "Geometry.h"

Point2D Geometry::projectFront(
        int ox,
        int oy,
        int row,
        int col,
        int s)
{
    return Point2D(
            ox + col*s,
            oy + row*s);
}

Point2D Geometry::projectTop(
        int ox,
        int oy,
        int row,
        int col,
        int s)
{
    return Point2D(
            ox + col*s - row*(s/2),
            oy - row*(s/2));
}

Point2D Geometry::projectRight(
        int ox,
        int oy,
        int row,
        int col,
        int s)
{
    return Point2D(
            ox + 3*s + col*(s/2),
            oy + row*s - col*(s/2));
}
