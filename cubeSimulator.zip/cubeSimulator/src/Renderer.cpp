#include "Renderer.h"

Renderer::Renderer(){
   window = nullptr;
   renderer = nullptr;
}

bool Renderer::initialize(){
  if(SDL_Init(SDL_INIT_VIDEO)!= 0)
     return false;
    
  window = SDL_CreateWindow(
                "Cube Orientation Simulator",
                SDL_WINDOWPOS_CENTERED,
                SDL_WINDOWPOS_CENTERED,
                1000,
                700,
                SDL_WINDOW_SHOWN
  );
  
  if(window == nullptr)
      return false;
      
  renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
  
  if(renderer == nullptr)
      return false;
      
  return true;
}

void Renderer::clear(){
   SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
   SDL_RenderClear(renderer);
}

void Renderer::present(){
   SDL_RenderPresent(renderer);
}

void Renderer::destroy(){
   SDL_DestroyRenderer(renderer);
   SDL_DestroyWindow(window);
   SDL_Quit();
}

//Destructor
Renderer::~Renderer(){
   destroy();
}

//Accessor
SDL_Renderer* Renderer::getRenderer(){
    return renderer;
}

void Renderer::setColor(Color color)
{
    switch(color)
    {
        case WHITE:
            SDL_SetRenderDrawColor(renderer,255,255,255,255);
            break;

        case YELLOW:
            SDL_SetRenderDrawColor(renderer,255,255,0,255);
            break;

        case GREEN:
            SDL_SetRenderDrawColor(renderer,0,200,0,255);
            break;

        case BLUE:
            SDL_SetRenderDrawColor(renderer,0,0,255,255);
            break;

        case ORANGE:
            SDL_SetRenderDrawColor(renderer,255,165,0,255);
            break;

        case RED:
            SDL_SetRenderDrawColor(renderer,220,0,0,255);
            break;
    }
}


void Renderer::drawCell(int x,
                        int y,
                        Color color)
{
    SDL_Rect cell;

    cell.x = x;
    cell.y = y;

    cell.w = 60;
    cell.h = 60;

    setColor(color);

    SDL_RenderFillRect(renderer,&cell);

    SDL_SetRenderDrawColor(renderer,0,0,0,255);

    SDL_RenderDrawRect(renderer,&cell);
}

void Renderer::drawFace(int x, int y, Color face[3][3])
{
    const int size = 60;

    for(int row=0; row<3; row++){
        for(int col=0; col<3; col++){
            drawCell(
                x + col*size,
                y + row*size,
                face[row][col]
            );
        }
    }
}

void Renderer::drawFrontFace(Color face[3][3], FaceGeometry& geo)
{
    for (int r = 0; r < 3; r++)
    {
        for (int c = 0; c < 3; c++)
        {
            drawQuad(geo.stickers[r][c], face[r][c]);
        }
    }
}

void Renderer::drawTopFace(Color face[3][3], FaceGeometry& geo)
{
    for (int r = 0; r < 3; r++)
    {
        for (int c = 0; c < 3; c++)
        {
            drawQuad(geo.stickers[r][c], face[r][c]);
        }
    }
}

void Renderer::drawRightFace(Color face[3][3], FaceGeometry& geo)
{
    for (int r = 0; r < 3; r++)
    {
        for (int c = 0; c < 3; c++)
        {
            drawQuad(geo.stickers[r][c], face[r][c]);
        }
    }
}

void Renderer::drawQuad(const Quad& q, Color color)
{
    SDL_Color sdlColor;

    switch (color)
    {
        case WHITE:  sdlColor = {255,255,255,255}; break;
        case YELLOW: sdlColor = {255,255,0,255};   break;
        case GREEN:  sdlColor = {0,180,0,255};     break;
        case BLUE:   sdlColor = {0,0,255,255};     break;
        case RED:    sdlColor = {255,0,0,255};     break;
        case ORANGE: sdlColor = {255,128,0,255};   break;
        default:     sdlColor = {128,128,128,255};
    }

    SDL_SetRenderDrawColor(renderer,
                           sdlColor.r,
                           sdlColor.g,
                           sdlColor.b,
                           255);

    SDL_RenderDrawLine(renderer, q.p[0].x, q.p[0].y, q.p[1].x, q.p[1].y);
    SDL_RenderDrawLine(renderer, q.p[1].x, q.p[1].y, q.p[2].x, q.p[2].y);
    SDL_RenderDrawLine(renderer, q.p[2].x, q.p[2].y, q.p[3].x, q.p[3].y);
    SDL_RenderDrawLine(renderer, q.p[3].x, q.p[3].y, q.p[0].x, q.p[0].y);
}

void Renderer::drawCube3D(Cube& cube)
{
    static FaceGeometry topGeo;
    static FaceGeometry frontGeo;
    static FaceGeometry rightGeo;

    static bool initialized = false;

    if (!initialized)
    {
        frontGeo.buildFront(400, 250, 50);
        topGeo.buildTop(400, 250, 50);
        rightGeo.buildRight(400, 250, 50);

        initialized = true;
    }

    drawTopFace(cube.getFace(TOP), topGeo);
    drawRightFace(cube.getFace(RIGHT), rightGeo);
    drawFrontFace(cube.getFace(FRONT), frontGeo);
}


