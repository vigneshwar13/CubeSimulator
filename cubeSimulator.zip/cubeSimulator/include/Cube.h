#ifndef CUBE_H
#define CUBE_H

#include <cstring>
#include "Color.h"


enum Face
{
    FRONT = 0,
    BACK,
    TOP,
    BOTTOM,
    LEFT,
    RIGHT
};

class Cube
{
private:

    Color cube[6][3][3];

public:

    Cube();

    void initialize();

    void rotateUp();
    void rotateDown();
    void rotateLeft();
    void rotateRight();

    Color (*getFace(Face face))[3];

    void reset();
};

#endif
