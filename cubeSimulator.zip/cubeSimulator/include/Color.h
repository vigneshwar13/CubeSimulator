#ifndef COLOR_H
#define COLOR_H

enum Color
{
    WHITE = 0,
    YELLOW,
    GREEN,
    BLUE,
    ORANGE,
    RED,
    BLACK
};

#endif
