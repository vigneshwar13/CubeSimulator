#ifndef GEOMETRY_H
#define GEOMETRY_H

#include "Point2D.h"

class Geometry
{
public:

    static Point2D projectFront(
            int originX,
            int originY,
            int row,
            int col,
            int sticker);

    static Point2D projectTop(
            int originX,
            int originY,
            int row,
            int col,
            int sticker);

    static Point2D projectRight(
            int originX,
            int originY,
            int row,
            int col,
            int sticker);
};

#endif
