#ifndef FACEGEOMETRY_H
#define FACEGEOMETRY_H

#include "Point2D.h"

struct Quad
{
    Point2D p[4];
};

class FaceGeometry
{
public:

    Quad stickers[3][3];

    void buildFront(
            int originX,
            int originY,
            int sticker);

    void buildTop(
            int originX,
            int originY,
            int sticker);

    void buildRight(
            int originX,
            int originY,
            int sticker);
};

#endif
