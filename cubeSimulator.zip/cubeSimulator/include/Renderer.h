#ifndef RENDERER_H
#define RENDERER_H

#include <SDL2/SDL.h>
#include "Cube.h"
#include "FaceGeometry.h"

class Renderer{
private:
   SDL_Window* window;
   SDL_Renderer* renderer;
   
public:
   Renderer();
   ~Renderer();
   bool initialize();
   void clear();
   void present();
   SDL_Renderer* getRenderer();
   void destroy();
   
   void setColor(Color color);
   void drawCell(int x, int y, Color color);
   void drawFace(int x, int y, Color face[3][3]);
   
   void drawCube3D(Cube& cube);
   void drawFrontFace(Color face[3][3], FaceGeometry& geo);
   void drawTopFace(Color face[3][3], FaceGeometry& geo);
   void drawRightFace(Color face[3][3], FaceGeometry& geo);
   void drawQuad(const Quad& quad, Color color);
};

#endif
