#ifndef POINT2D_H
#define POINT2D_H

struct Point2D
{
    int x;
    int y;

    Point2D()
    {
        x = 0;
        y = 0;
    }

    Point2D(int px, int py)
    {
        x = px;
        y = py;
    }
};

#endif
